using Microsoft.AspNetCore.Mvc;
using FinanceBudget.Models;
using FinanceBudget.Services;

namespace FinanceBudget.Controllers;

public class DashboardController : Controller
{
    private readonly IUnitBudgetService _unitBudgetService;
    private readonly IAFEDataService _afeDataService;
    private readonly IJiraCostingService _jiraCostingService;
    private readonly ILogger<DashboardController> _logger;

    public DashboardController(
        IUnitBudgetService unitBudgetService,
        IAFEDataService afeDataService,
        IJiraCostingService jiraCostingService,
        ILogger<DashboardController> logger)
    {
        _unitBudgetService = unitBudgetService;
        _afeDataService = afeDataService;
        _jiraCostingService = jiraCostingService;
        _logger = logger;
    }

    public async Task<IActionResult> Index(string? unitCode = null, string? natureId = null)
    {
        try
        {
            // Always fetch dropdown data
            var allUnits = await _unitBudgetService.GetAllUnitsAsync();

            // Initialize view model with dropdown data
            var viewModel = new DashboardViewModel
            {
                AvailableUnits = allUnits
            };

            // Only fetch data if a unit is selected
            if (!string.IsNullOrEmpty(unitCode))
            {
                // Fetch natures for selected unit
                var availableNatures = await _unitBudgetService.GetNaturesByUnitAsync(unitCode);
                viewModel.AvailableNatures = availableNatures;

                // Fetch data from all three sources in parallel
                var unitBudgetTask = _unitBudgetService.GetUnitBudgetDataAsync(unitCode, natureId);
                var afeDataTask = _afeDataService.GetAFEDataAsync(unitCode);
                var jiraCostingTask = _jiraCostingService.GetJiraCostingDataAsync(unitCode);

                await Task.WhenAll(unitBudgetTask, afeDataTask, jiraCostingTask);

                var unitBudgets = await unitBudgetTask;
                var afeData = await afeDataTask;
                var jiraCostings = await jiraCostingTask;

                // Calculate Credit (positive amounts) and Debit (negative amounts)
                var totalCredit = unitBudgets.Where(u => u.Amount > 0).Sum(u => u.Amount);
                var totalDebit = Math.Abs(unitBudgets.Where(u => u.Amount < 0).Sum(u => u.Amount));

                // Populate view model with data
                viewModel.UnitBudgets = unitBudgets;
                viewModel.AFEDataList = afeData;
                viewModel.JiraCostings = jiraCostings;
                viewModel.TotalBudgetAmount = unitBudgets.Sum(u => u.Amount);
                viewModel.TotalBudgetCredit = totalCredit;
                viewModel.TotalBudgetDebit = totalDebit;
                viewModel.TotalAFEApproved = afeData.Sum(a => a.ApprovedAmount);
                viewModel.TotalAFESpent = afeData.Sum(a => a.SpentAmount);
                viewModel.TotalJiraEstimated = jiraCostings.Sum(j => j.EstimatedCost);
                viewModel.TotalJiraActual = jiraCostings.Sum(j => j.ActualCost);

                // Build unit summaries
                var units = unitBudgets.Select(u => u.Unit).Distinct();
                foreach (var unit in units)
                {
                    var unitBudgetData = unitBudgets.Where(u => u.Unit == unit).ToList();
                    var unitAFEData = afeData.Where(a => a.Unit == unit).ToList();
                    var unitJiraData = jiraCostings.Where(j => j.Unit == unit).ToList();

                    viewModel.UnitSummaries[unit] = new UnitSummary
                    {
                        Unit = unit,
                        UnitDescription = unitBudgetData.FirstOrDefault()?.UnitDescription ?? "",
                        BudgetAmount = unitBudgetData.Sum(u => u.Amount),
                        AFEAmount = unitAFEData.Sum(a => a.ApprovedAmount),
                        JiraAmount = unitJiraData.Sum(j => j.EstimatedCost),
                        TotalAmount = unitBudgetData.Sum(u => u.Amount) +
                                      unitAFEData.Sum(a => a.ApprovedAmount) +
                                      unitJiraData.Sum(j => j.EstimatedCost),
                        TransactionCount = unitBudgetData.Count,
                        AFECount = unitAFEData.Count,
                        JiraIssueCount = unitJiraData.Count
                    };
                }
            }

            ViewBag.SelectedUnit = unitCode;
            ViewBag.SelectedNature = natureId;
            return View(viewModel);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error loading dashboard");
            TempData["Error"] = "An error occurred while loading the dashboard. Please try again.";

            // Return empty view model with dropdown data
            var emptyViewModel = new DashboardViewModel();
            try
            {
                emptyViewModel.AvailableUnits = await _unitBudgetService.GetAllUnitsAsync();
            }
            catch { }

            return View(emptyViewModel);
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetNaturesByUnit(string unitCode)
    {
        try
        {
            var natures = await _unitBudgetService.GetNaturesByUnitAsync(unitCode);
            return Json(natures);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching natures for unit {UnitCode}", unitCode);
            return BadRequest("Error fetching natures");
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetUnitDetails(string unitCode)
    {
        try
        {
            var unitBudgets = await _unitBudgetService.GetUnitBudgetDataAsync(unitCode);
            return Json(unitBudgets);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching unit details");
            return BadRequest("Error fetching unit details");
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetAFEDetails(string unitCode)
    {
        try
        {
            var afeData = await _afeDataService.GetAFEDataAsync(unitCode);
            return Json(afeData);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching AFE details");
            return BadRequest("Error fetching AFE details");
        }
    }

    [HttpGet]
    public async Task<IActionResult> GetJiraDetails(string unitCode)
    {
        try
        {
            var jiraData = await _jiraCostingService.GetJiraCostingDataAsync(unitCode);
            return Json(jiraData);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching JIRA details");
            return BadRequest("Error fetching JIRA details");
        }
    }

    [HttpGet]
    public async Task<IActionResult> ExportData(string? unitCode = null, string format = "json")
    {
        try
        {
            var unitBudgets = await _unitBudgetService.GetUnitBudgetDataAsync(unitCode);
            var afeData = await _afeDataService.GetAFEDataAsync(unitCode);
            var jiraCostings = await _jiraCostingService.GetJiraCostingDataAsync(unitCode);

            var exportData = new
            {
                UnitBudgets = unitBudgets,
                AFEData = afeData,
                JiraCostings = jiraCostings,
                ExportDate = DateTime.Now
            };

            if (format.ToLower() == "json")
            {
                return Json(exportData);
            }

            return BadRequest("Unsupported export format");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error exporting data");
            return BadRequest("Error exporting data");
        }
    }
}

