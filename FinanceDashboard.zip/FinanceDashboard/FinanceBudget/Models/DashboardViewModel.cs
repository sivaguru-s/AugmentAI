namespace FinanceBudget.Models;

public class DashboardViewModel
{
    public List<UnitBudget> UnitBudgets { get; set; } = new();
    public List<AFEData> AFEDataList { get; set; } = new();
    public List<JiraCosting> JiraCostings { get; set; } = new();

    // Dropdown data
    public List<Unit> AvailableUnits { get; set; } = new();
    public List<Nature> AvailableNatures { get; set; } = new();

    // Summary Statistics
    public decimal TotalBudgetAmount { get; set; }
    public decimal TotalBudgetCredit { get; set; }
    public decimal TotalBudgetDebit { get; set; }
    public decimal TotalAFEApproved { get; set; }
    public decimal TotalAFESpent { get; set; }
    public decimal TotalJiraEstimated { get; set; }
    public decimal TotalJiraActual { get; set; }

    // Unit-wise aggregation
    public Dictionary<string, UnitSummary> UnitSummaries { get; set; } = new();
}

public class UnitSummary
{
    public string Unit { get; set; } = string.Empty;
    public string UnitDescription { get; set; } = string.Empty;
    public decimal BudgetAmount { get; set; }
    public decimal AFEAmount { get; set; }
    public decimal JiraAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public int TransactionCount { get; set; }
    public int AFECount { get; set; }
    public int JiraIssueCount { get; set; }
}

